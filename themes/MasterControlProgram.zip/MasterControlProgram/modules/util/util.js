$(document).ready(function() {
	$('link[href="modules/util/util.css"]').remove();
});
