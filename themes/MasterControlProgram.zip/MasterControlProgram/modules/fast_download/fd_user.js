$(document).ready(function() {
	$('b').removeAttr('style');
	$('input[name="delete"]').removeClass('btn-primary').addClass('btn-danger');
});
