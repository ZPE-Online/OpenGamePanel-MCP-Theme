$(document).ready(function(){
	$('.main [href^="?m=gamemanager&p=game_monitor"], .main [href^="?m=editconfigfiles"]').addClass('btn').addClass('btn-primary').addClass('btn-xs');
});
