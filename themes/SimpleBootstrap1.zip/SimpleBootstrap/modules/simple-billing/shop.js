$(document).ready(function() {
	$('.main [href="?m=simple-billing&p=cart"]').addClass('btn').addClass('btn-sm').addClass('btn-primary').prepend('<i class="fa fa-shopping-cart" aria-hidden="true"></i>');
});
