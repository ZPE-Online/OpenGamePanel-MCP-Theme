$(document).ready(function() {
        $('.main [href="?m=user_games"]').addClass('btn').addClass('btn-primary').addClass('btn-sm');

});


